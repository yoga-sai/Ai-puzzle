import { db } from "../db/connection.js"
import crypto from "crypto"

export function upsertProgress({ user_id, puzzle_id, is_correct, score, time_taken }) {
  const existing = db.prepare("SELECT id, attempts, best_score, best_time FROM progress WHERE user_id = ? AND puzzle_id = ?").get(user_id, puzzle_id)
  if (!existing) {
    const id = crypto.randomUUID()
    const stmt = db.prepare("INSERT INTO progress(id, user_id, puzzle_id, status, attempts, best_score, best_time, last_attempt) VALUES(?,?,?,?,?,?,?,datetime('now'))")
    stmt.run(id, user_id, puzzle_id, is_correct ? 'completed' : 'in_progress', 1, score, time_taken,)
    return id
  } else {
    const attempts = existing.attempts + 1
    const best_score = Math.max(existing.best_score || 0, score)
    const best_time = existing.best_time ? Math.min(existing.best_time, time_taken) : time_taken
    const stmt = db.prepare("UPDATE progress SET status = ?, attempts = ?, best_score = ?, best_time = ?, last_attempt = datetime('now'), updated_at = datetime('now') WHERE id = ?")
    stmt.run(is_correct ? 'completed' : 'in_progress', attempts, best_score, best_time, existing.id)
    return existing.id
  }
}