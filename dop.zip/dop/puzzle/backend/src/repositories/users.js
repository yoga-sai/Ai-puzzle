import { db } from "../db/connection.js"
import bcrypt from "bcryptjs"
import crypto from "crypto"

export function findByEmail(email) {
  const stmt = db.prepare("SELECT id, email, password_hash, name, role FROM users WHERE email = ?")
  return stmt.get(email)
}

export function createUser({ email, password, name, role }) {
  const id = crypto.randomUUID()
  const password_hash = bcrypt.hashSync(password, 12)
  const stmt = db.prepare("INSERT INTO users(id, email, password_hash, name, role) VALUES(?,?,?,?,?)")
  stmt.run(id, email, password_hash, name, role)
  return { id, email, name, role }
}