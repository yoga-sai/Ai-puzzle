import { db } from "../db/connection.js"
import crypto from "crypto"

export function recordSolution({ user_id, puzzle_id, solution_order, is_correct, score, time_taken, feedback }) {
  const id = crypto.randomUUID()
  const stmt = db.prepare("INSERT INTO solutions(id, user_id, puzzle_id, solution_order, is_correct, score, time_taken, feedback) VALUES(?,?,?,?,?,?,?,?)")
  stmt.run(id, user_id || null, puzzle_id, JSON.stringify(solution_order), is_correct ? 1 : 0, score, time_taken, feedback ? JSON.stringify(feedback) : null)
  return id
}