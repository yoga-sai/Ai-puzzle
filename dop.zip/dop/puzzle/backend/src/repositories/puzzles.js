import { db } from "../db/connection.js"
import crypto from "crypto"

export function getAll({ difficulty, category, limit }) {
  let sql = "SELECT id, title, description, difficulty, category, segments, correct_order, created_by FROM puzzles WHERE 1=1"
  const params = []
  if (difficulty) { sql += " AND difficulty = ?"; params.push(difficulty) }
  if (category) { sql += " AND category = ?"; params.push(category) }
  sql += " ORDER BY created_at DESC"
  if (limit) { sql += " LIMIT ?"; params.push(Number(limit)) }
  const rows = db.prepare(sql).all(...params)
  return rows.map(r => ({
    ...r,
    segments: JSON.parse(r.segments),
    correct_order: JSON.parse(r.correct_order)
  }))
}

export function create({ title, description, difficulty, category, segments, correct_order, created_by }) {
  const id = crypto.randomUUID()
  const stmt = db.prepare("INSERT INTO puzzles(id, title, description, difficulty, category, segments, correct_order, created_by) VALUES(?,?,?,?,?,?,?,?)")
  stmt.run(id, title, description, difficulty, category, JSON.stringify(segments), JSON.stringify(correct_order), created_by || null)
  return { id, title, description, difficulty, category, segments, correct_order, created_by }
}

export function getById(id) {
  const r = db.prepare("SELECT id, title, description, difficulty, category, segments, correct_order, created_by FROM puzzles WHERE id = ?").get(id)
  if (!r) return null
  return { ...r, segments: JSON.parse(r.segments), correct_order: JSON.parse(r.correct_order) }
}