import { db } from "./connection.js"

export function ensureSchema() {
  db.exec(`PRAGMA foreign_keys = ON;`)
  db.exec(`CREATE TABLE IF NOT EXISTS users (
    id TEXT PRIMARY KEY,
    email TEXT UNIQUE NOT NULL,
    password_hash TEXT NOT NULL,
    name TEXT NOT NULL,
    role TEXT NOT NULL CHECK (role IN ('student','instructor')),
    created_at TEXT DEFAULT (datetime('now')),
    updated_at TEXT DEFAULT (datetime('now'))
  );`)
  db.exec(`CREATE TABLE IF NOT EXISTS puzzles (
    id TEXT PRIMARY KEY,
    title TEXT NOT NULL,
    description TEXT NOT NULL,
    difficulty TEXT CHECK (difficulty IN ('easy','medium','hard')),
    category TEXT NOT NULL,
    segments TEXT NOT NULL,
    correct_order TEXT NOT NULL,
    created_by TEXT,
    created_at TEXT DEFAULT (datetime('now')),
    updated_at TEXT DEFAULT (datetime('now')),
    FOREIGN KEY(created_by) REFERENCES users(id)
  );`)
  db.exec(`CREATE TABLE IF NOT EXISTS solutions (
    id TEXT PRIMARY KEY,
    user_id TEXT,
    puzzle_id TEXT,
    solution_order TEXT NOT NULL,
    is_correct INTEGER NOT NULL,
    score INTEGER CHECK (score >= 0 AND score <= 100),
    time_taken INTEGER NOT NULL,
    feedback TEXT,
    created_at TEXT DEFAULT (datetime('now')),
    FOREIGN KEY(user_id) REFERENCES users(id),
    FOREIGN KEY(puzzle_id) REFERENCES puzzles(id)
  );`)
  db.exec(`CREATE TABLE IF NOT EXISTS progress (
    id TEXT PRIMARY KEY,
    user_id TEXT,
    puzzle_id TEXT,
    status TEXT DEFAULT 'not_started' CHECK (status IN ('not_started','in_progress','completed')),
    attempts INTEGER DEFAULT 0,
    best_score INTEGER DEFAULT 0,
    best_time INTEGER DEFAULT 0,
    last_attempt TEXT,
    created_at TEXT DEFAULT (datetime('now')),
    updated_at TEXT DEFAULT (datetime('now')),
    UNIQUE(user_id, puzzle_id),
    FOREIGN KEY(user_id) REFERENCES users(id),
    FOREIGN KEY(puzzle_id) REFERENCES puzzles(id)
  );`)
}