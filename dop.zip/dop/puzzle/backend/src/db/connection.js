import Database from "better-sqlite3"
import path from "path"
import fs from "fs"

const dbPath = process.env.DB_PATH || path.join(process.cwd(), "data", "puzzle.db")
fs.mkdirSync(path.dirname(dbPath), { recursive: true })
export const db = new Database(dbPath)