import "dotenv/config"
import app from "./setup/app.js"
import { ensureSchema } from "./db/schema.js"

const port = process.env.PORT || 3001
ensureSchema()
app.listen(port, () => {})