## 1. Architecture Design

```mermaid
graph TD
  A[User Browser] --> B[React Frontend Application]
  B --> C[Node.js Backend API]
  C --> D[Supabase Database]
  C --> E[Authentication Service]
  B --> F[Supabase Storage]

  subgraph "Frontend Layer"
    B
  end

  subgraph "Backend Layer"
    C
    E
  end

  subgraph "Data Layer"
    D
    F
  end
```

## 2. Technology Description

* **Frontend**: React\@18 + tailwindcss\@3 + vite

* **Initialization Tool**: vite-init

* **Backend**: Node.js\@18 + Express\@4

* **Database**: Supabase (PostgreSQL)

* **Authentication**: Supabase Auth with JWT tokens

* **File Storage**: Supabase Storage for puzzle assets

## 3. Route Definitions

| Route                 | Purpose                                         |
| --------------------- | ----------------------------------------------- |
| /                     | Home page with app overview and navigation      |
| /login                | User authentication page                        |
| /register             | User registration with role selection           |
| /student/dashboard    | Student dashboard with puzzle list and progress |
| /student/puzzle/:id   | Puzzle solving interface                        |
| /instructor/dashboard | Instructor dashboard with analytics             |
| /instructor/puzzles   | Puzzle management and creation                  |
| /instructor/analytics | Student progress analytics                      |

## 4. API Definitions

### 4.1 Authentication APIs

**Login**

```
POST /api/auth/login
```

Request:

| Param Name | Param Type | isRequired | Description                    |
| ---------- | ---------- | ---------- | ------------------------------ |
| email      | string     | true       | User email address             |
| password   | string     | true       | User password                  |
| role       | string     | true       | User role (student/instructor) |

Response:

```json
{
  "token": "jwt_token_string",
  "user": {
    "id": "user_id",
    "email": "user@example.com",
    "role": "student",
    "name": "John Doe"
  }
}
```

**Register**

```
POST /api/auth/register
```

Request:

| Param Name | Param Type | isRequired | Description                    |
| ---------- | ---------- | ---------- | ------------------------------ |
| email      | string     | true       | User email address             |
| password   | string     | true       | User password (min 6 chars)    |
| name       | string     | true       | Full name                      |
| role       | string     | true       | User role (student/instructor) |

### 4.2 Puzzle APIs

**Get All Puzzles**

```
GET /api/puzzles
```

Query Parameters:

| Param Name | Param Type | isRequired | Description                             |
| ---------- | ---------- | ---------- | --------------------------------------- |
| difficulty | string     | false      | Filter by difficulty (easy/medium/hard) |
| category   | string     | false      | Filter by category                      |
| limit      | number     | false      | Number of puzzles to return             |

Response:

```json
{
  "puzzles": [
    {
      "id": "puzzle_id",
      "title": "Array Sum Algorithm",
      "description": "Calculate sum of array elements",
      "difficulty": "easy",
      "category": "arrays",
      "segments": ["segment1", "segment2", "segment3"],
      "correct_order": [0, 1, 2],
      "created_by": "instructor_id"
    }
  ]
}
```

**Create Puzzle**

```
POST /api/puzzles
```

Request:

| Param Name     | Param Type | isRequired | Description                  |
| -------------- | ---------- | ---------- | ---------------------------- |
| title          | string     | true       | Puzzle title                 |
| description    | string     | true       | Puzzle description           |
| difficulty     | string     | true       | Difficulty level             |
| category       | string     | true       | Puzzle category              |
| segments       | array      | true       | Array of pseudocode segments |
| correct\_order | array      | true       | Correct order of segments    |

**Submit Solution**

```
POST /api/puzzles/:id/submit
```

Request:

| Param Name      | Param Type | isRequired | Description                   |
| --------------- | ---------- | ---------- | ----------------------------- |
| solution\_order | array      | true       | Student's ordered segments    |
| time\_taken     | number     | true       | Time taken to solve (seconds) |

Response:

```json
{
  "correct": true,
  "feedback": "Great job! Your solution is correct.",
  "score": 100,
  "hints": []
}
```

## 5. Server Architecture Diagram

```mermaid
graph TD
  A[Client / Frontend] --> B[API Gateway]
  B --> C[Auth Middleware]
  C --> D[Controllers]
  D --> E[Services]
  E --> F[Repository Layer]
  F --> G[(Supabase Database)]
  E --> H[Supabase Storage]

  subgraph "Backend Server"
    B
    C
    D
    E
    F
  end
```

## 6. Data Model

### 6.1 Data Model Definition

```mermaid
erDiagram
  USERS ||--o{ PUZZLES : creates
  USERS ||--o{ SOLUTIONS : submits
  PUZZLES ||--o{ SOLUTIONS : has
  USERS ||--o{ PROGRESS : tracks

  USERS {
    UUID id PK
    STRING email
    STRING password_hash
    STRING name
    STRING role
    TIMESTAMP created_at
  }

  PUZZLES {
    UUID id PK
    STRING title
    STRING description
    STRING difficulty
    STRING category
    JSON segments
    JSON correct_order
    UUID created_by FK
    TIMESTAMP created_at
  }

  SOLUTIONS {
    UUID id PK
    UUID user_id FK
    UUID puzzle_id FK
    JSON solution_order
    BOOLEAN is_correct
    INTEGER score
    INTEGER time_taken
    JSON feedback
    TIMESTAMP created_at
  }

  PROGRESS {
    UUID id PK
    UUID user_id FK
    UUID puzzle_id FK
    STRING status
    INTEGER attempts
    INTEGER best_score
    INTEGER best_time
    TIMESTAMP last_attempt
  }
```

### 6.2 Data Definition Language

**Users Table**

```sql
CREATE TABLE users (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  email VARCHAR(255) UNIQUE NOT NULL,
  password_hash VARCHAR(255) NOT NULL,
  name VARCHAR(100) NOT NULL,
  role VARCHAR(20) NOT NULL CHECK (role IN ('student', 'instructor')),
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
  updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Indexes
CREATE INDEX idx_users_email ON users(email);
CREATE INDEX idx_users_role ON users(role);
```

**Puzzles Table**

```sql
CREATE TABLE puzzles (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  title VARCHAR(255) NOT NULL,
  description TEXT NOT NULL,
  difficulty VARCHAR(20) CHECK (difficulty IN ('easy', 'medium', 'hard')),
  category VARCHAR(50) NOT NULL,
  segments JSONB NOT NULL,
  correct_order JSONB NOT NULL,
  created_by UUID REFERENCES users(id),
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
  updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Indexes
CREATE INDEX idx_puzzles_difficulty ON puzzles(difficulty);
CREATE INDEX idx_puzzles_category ON puzzles(category);
CREATE INDEX idx_puzzles_created_by ON puzzles(created_by);
```

**Solutions Table**

```sql
CREATE TABLE solutions (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID REFERENCES users(id),
  puzzle_id UUID REFERENCES puzzles(id),
  solution_order JSONB NOT NULL,
  is_correct BOOLEAN NOT NULL,
  score INTEGER CHECK (score >= 0 AND score <= 100),
  time_taken INTEGER NOT NULL, -- in seconds
  feedback JSONB,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Indexes
CREATE INDEX idx_solutions_user_id ON solutions(user_id);
CREATE INDEX idx_solutions_puzzle_id ON solutions(puzzle_id);
CREATE INDEX idx_solutions_created_at ON solutions(created_at DESC);
```

**Progress Table**

```sql
CREATE TABLE progress (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID REFERENCES users(id),
  puzzle_id UUID REFERENCES puzzles(id),
  status VARCHAR(20) DEFAULT 'not_started' CHECK (status IN ('not_started', 'in_progress', 'completed')),
  attempts INTEGER DEFAULT 0,
  best_score INTEGER DEFAULT 0,
  best_time INTEGER DEFAULT 0, -- in seconds
  last_attempt TIMESTAMP WITH TIME ZONE,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
  updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
  UNIQUE(user_id, puzzle_id)
);

-- Indexes
CREATE INDEX idx_progress_user_id ON progress(user_id);
CREATE INDEX idx_progress_puzzle_id ON progress(puzzle_id);
```

## 7. Security Considerations

### Authentication & Authorization

* JWT-based authentication with refresh tokens

* Role-based access control (RBAC) for student/instructor permissions

* Password hashing with bcrypt (12 rounds)

* Rate limiting on authentication endpoints (5 attempts per 15 minutes)

### Input Validation

* Server-side validation for all API inputs

* SQL injection prevention through parameterized queries

* XSS protection via output encoding

* File upload validation (size limits, type restrictions)

### Data Protection

* HTTPS enforcement in production

* Secure cookie settings (HttpOnly, Secure, SameSite)

* CORS configuration for cross-origin requests

* Database connection encryption

## 8. Performance Requirements

### Response Times

* API response time: < 200ms for standard queries

* Page load time: < 3 seconds on 3G connection

* Drag-and-drop responsiveness: < 50ms delay

### Scalability

* Support for 1000+ concurrent users

* Database queries optimized with proper indexing

* Pagination for large puzzle lists

* Caching strategy for frequently accessed data

### Resource Usage

* Frontend bundle size: < 500KB gzipped

* Database connection pooling (10-20 connections)

* Memory usage: < 256MB per container

## 9. Deployment Architecture

### Local Development

* Docker Compose for local development environment

* Hot reload for both frontend and backend

* Database migrations on startup

### Production Deployment

* Container orchestration with Docker Swarm or Kubernetes

* Load balancing with Nginx

* SSL termination at load balancer

* Database backups and monitoring

* Auto-scaling based on CPU/memory usage

